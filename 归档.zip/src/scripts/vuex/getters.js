export const getTabIndex = state => state.tabIndex;
export const getUserName = state=>state.userName;
export const getTabindex = function(state) {
  return state.classifyIndex;
};
