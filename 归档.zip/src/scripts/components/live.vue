<template>
  <div class="livBox">
    <header class="liveBoxHeader">
      <span></span>
      <ul>
        <li>直播</li>
        <li>新帖</li>
        <li>热帖</li>
      </ul>
      <span></span>
    </header>
    <nav class="liveBoxNav">
      <img src="/images/1.png" alt="">
    </nav>
    <section class="liveBoxSection">

    </section>
  </div>
</template>
<script>

</script>
