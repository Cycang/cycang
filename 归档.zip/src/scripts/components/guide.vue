<template>
  <div class="guide-container">
    <img src="/images/splash.png" v-link = "{path: '/index'}" alt="" />
  </div>
</template>
