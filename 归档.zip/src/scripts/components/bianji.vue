<template>
  <div class="bianji-container">
    <header>
    <div class="title-left">

    </div>
    <div class="title">
      个人资料
    </div>
    <div class="title-right">
      完成
    </div>
    </header>
    <section>
      <div class="name">
        <p>昵称</p>
        <input type="text" name="name" value="" v-module="" placeholder="请填写昵称">
      </div>
      <div class="youxiang">
        <p>邮箱</p>
        <input type="text" name="name" value="" v-module="" placeholder="请填写邮箱">
      </div>
      <div class="QQ">
        <p>QQ</p>
        <input type="text" name="name" value="" v-module="" placeholder="请填写QQ">
      </div>
    </section>
  </div>
</template>
